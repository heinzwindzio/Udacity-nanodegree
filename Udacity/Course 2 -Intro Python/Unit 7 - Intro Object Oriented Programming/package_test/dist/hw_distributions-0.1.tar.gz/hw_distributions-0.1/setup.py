from setuptools import setup

setup(name="hw-distributions", 
 version="0.1",
 description="Gaussian distributions", 
 packages=['hw-distributions'],
 zip_safe=False)

