from .Gaussiandistribution import Gaussian
from .Generaldistribution import Distribution

